// src/events/dto/update-event.dto.ts
import { PartialType } from '@nestjs/mapped-types'; // 需要安装: npm i @nestjs/mapped-types
import { CreateEventDto } from './create-event.dto';

export class UpdateEventDto extends PartialType(CreateEventDto) {}