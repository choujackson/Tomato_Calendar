import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Plan {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  startDate: string; // YYYY-MM-DD格式
  endDate: string; // YYYY-MM-DD格式
  location?: string;
  color: string;
  allDay: boolean;
  repeat: string;
  notes: string;
}

interface PlanContextType {
  plans: Plan[];
  addPlan: (plan: Plan) => void;
  updatePlan: (id: string, plan: Plan) => void;
  deletePlan: (id: string) => void;
  getPlansForDate: (date: string) => Plan[]; // date格式：YYYY-MM-DD
}

const PlanContext = createContext<PlanContextType | undefined>(undefined);

export function PlanProvider({ children }: { children: ReactNode }) {
  const [plans, setPlans] = useState<Plan[]>([]);

  const addPlan = (plan: Plan) => {
    setPlans((prev) => [...prev, plan]);
  };

  const updatePlan = (id: string, updatedPlan: Plan) => {
    setPlans((prev) => prev.map((p) => (p.id === id ? updatedPlan : p)));
  };

  const deletePlan = (id: string) => {
    setPlans((prev) => prev.filter((p) => p.id !== id));
  };

  const getPlansForDate = (date: string): Plan[] => {
    // 返回在指定日期范围内的所有计划
    return plans.filter((plan) => {
      // 如果计划的开始日期或结束日期包含这个日期，就显示
      return plan.startDate <= date && plan.endDate >= date;
    });
  };

  return (
    <PlanContext.Provider value={{ plans, addPlan, updatePlan, deletePlan, getPlansForDate }}>
      {children}
    </PlanContext.Provider>
  );
}

export function usePlan() {
  const context = useContext(PlanContext);
  if (context === undefined) {
    throw new Error('usePlan must be used within a PlanProvider');
  }
  return context;
}
