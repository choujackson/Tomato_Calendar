import React, { useRef, useState, useEffect } from 'react';
import { View, Text, StyleSheet, Dimensions, PanResponder, ScrollView, TouchableOpacity, Animated, Switch, Appearance, useColorScheme } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { SvgXml } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { RootStackParamList } from '../../App';
import GridBackground from '../components/GridBackground';

const { width, height } = Dimensions.get('window');

type UserProfileScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'UserProfile'>;

// Photo SVG from assets
const photoSvg = `<svg width="153" height="146" viewBox="0 0 153 146" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="153" height="140.237" fill="#FFD9AA"/>
<rect y="5.76318" width="153" height="140.237" fill="#FFD9AA"/>
<path d="M7.46339 9.04784L7.46338 83.69C57.8414 18.0954 46.6463 18.0954 97.0243 83.69C126.878 42.9761 125.012 47.4999 145.536 83.69V9.04761L7.46339 9.04784Z" fill="white"/>
</svg>`;

// Menu Icon SVG from assets
const menuIconSvg = `<svg width="19" height="17" viewBox="0 0 19 17" fill="none" xmlns="http://www.w3.org/2000/svg">
<line x1="1" y1="8.5" x2="18" y2="8.5" stroke="black" stroke-width="2" stroke-linecap="round"/>
<line x1="1" y1="1" x2="18" y2="1" stroke="black" stroke-width="2" stroke-linecap="round"/>
<line x1="1" y1="16" x2="18" y2="16" stroke="black" stroke-width="2" stroke-linecap="round"/>
</svg>`;


export default function UserProfileScreen() {
  const navigation = useNavigation<UserProfileScreenNavigationProp>();
  const scale = width / 393;
  
  // Sidebar state
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const sidebarTranslateX = useRef(new Animated.Value(width)).current;
  
  // Dark Mode settings state - only one can be active at a time
  const [darkModeEnabled, setDarkModeEnabled] = useState(false);
  const [automaticEnabled, setAutomaticEnabled] = useState(false);
  const [followSystemEnabled, setFollowSystemEnabled] = useState(false);
  
  // Current theme mode: 'light' | 'dark' | 'auto' | 'system'
  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark' | 'auto' | 'system'>('light');
  
  // State to track current time for automatic mode
  const [currentTime, setCurrentTime] = useState(new Date());

  // PanResponder removed - gestures are now handled by CalendarView's sidePanelPanResponder
  // Left swipe will close the side panel, returning to Calendar view

  // Open sidebar
  const openSidebar = () => {
    setSidebarVisible(true);
    Animated.timing(sidebarTranslateX, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start();
  };

  // Close sidebar
  const closeSidebar = () => {
    Animated.timing(sidebarTranslateX, {
      toValue: width,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      setSidebarVisible(false);
    });
  };

  // Get system color scheme
  const systemColorScheme = useColorScheme();

  // Determine effective theme based on current settings
  const getEffectiveTheme = (): 'light' | 'dark' => {
    if (currentTheme === 'system' && followSystemEnabled) {
      return systemColorScheme === 'dark' ? 'dark' : 'light';
    } else if (currentTheme === 'auto' && automaticEnabled) {
      // Automatic mode: dark mode from 18:00 to 6:00
      const hour = currentTime.getHours();
      return hour >= 18 || hour < 6 ? 'dark' : 'light';
    } else if (currentTheme === 'dark' && darkModeEnabled) {
      return 'dark';
    }
    return 'light';
  };

  // Calculate effective theme
  const effectiveTheme = getEffectiveTheme();

  // Handle Dark Mode toggle - mutually exclusive
  const handleDarkModeToggle = (value: boolean) => {
    if (value) {
      setDarkModeEnabled(true);
      setAutomaticEnabled(false);
      setFollowSystemEnabled(false);
      setCurrentTheme('dark');
    } else {
      setDarkModeEnabled(false);
      setCurrentTheme('light');
    }
  };

  // Handle Automatic toggle - mutually exclusive
  const handleAutomaticToggle = (value: boolean) => {
    if (value) {
      setAutomaticEnabled(true);
      setDarkModeEnabled(false);
      setFollowSystemEnabled(false);
      setCurrentTheme('auto');
    } else {
      setAutomaticEnabled(false);
      setCurrentTheme('light');
    }
  };

  // Handle Follow System toggle - mutually exclusive
  const handleFollowSystemToggle = (value: boolean) => {
    if (value) {
      setFollowSystemEnabled(true);
      setDarkModeEnabled(false);
      setAutomaticEnabled(false);
      setCurrentTheme('system');
    } else {
      setFollowSystemEnabled(false);
      setCurrentTheme('light');
    }
  };

  // Listen to system theme changes when follow system is enabled
  useEffect(() => {
    if (followSystemEnabled && currentTheme === 'system') {
      // Theme will be updated automatically via getEffectiveTheme
      // This effect ensures we react to system changes
    }
  }, [systemColorScheme, followSystemEnabled, currentTheme]);

  // Update theme for automatic mode based on time
  useEffect(() => {
    if (automaticEnabled && currentTheme === 'auto') {
      const interval = setInterval(() => {
        setCurrentTime(new Date()); // Update time to trigger re-render
      }, 60000); // Check every minute

      return () => clearInterval(interval);
    }
  }, [automaticEnabled, currentTheme]);

  // Handle logout
  const handleLogout = async () => {
    try {
      // Clear stored authentication data
      await AsyncStorage.removeItem('access_token');
      await AsyncStorage.removeItem('user');
      
      // Close sidebar
      closeSidebar();
      
      // Navigate to login screen and reset navigation stack
      navigation.reset({
        index: 0,
        routes: [{ name: 'Login' }],
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <View style={styles.container}>
      <GridBackground theme={effectiveTheme} />
      
      {/* Menu Icon - Fixed at top right */}
      <TouchableOpacity
        style={[styles.menuIconButton, {
          top: 60 * scale,
          right: 20 * scale,
        }]}
        onPress={openSidebar}
        activeOpacity={0.7}
      >
        <SvgXml xml={menuIconSvg} width={19 * scale} height={17 * scale} />
      </TouchableOpacity>
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Section - White grid background */}
        <View style={styles.profileSection}>
          {/* Profile Photo - Yellow Circle */}
          <View style={[styles.avatarCircle, {
            width: 153 * scale * 0.75,
            height: 153 * scale * 0.75,
            borderRadius: (153 * scale * 0.75) / 2,
            marginTop: 120 * scale ,
          }]} />

          {/* User Name */}
          <Text style={[styles.userName, {
            fontSize: 20 * scale * 2,
            marginTop: 20 * scale,
            fontWeight: '700',
          }]}>User Name</Text>

          {/* Signature */}
          <Text style={[styles.signature, {
            fontSize: 14 * scale,
            marginTop: 8 * scale,
          }]}>This is a personalized signature.</Text>
        </View>

        {/* Statistics and Diary Section - Light yellow background with top border radius */}
        <View style={[styles.yellowSection, {
          marginTop: 20 * scale,
          borderTopLeftRadius: 30 * scale,
          borderTopRightRadius: 30 * scale,
          paddingTop: 20 * scale,
          paddingHorizontal: 30 * scale,
        }]}>
          {/* Statistics Section */}
          <View style={styles.statsContainer}>
            {/* Left Stat */}
            <View style={styles.statItem}>
              <Text style={[styles.statNumber, { fontSize: 32 * scale }]}>312</Text>
              <Text style={[styles.statUnit, { fontSize: 14 * scale }]}>pcs</Text>
              <Text style={[styles.statLabel, { fontSize: 12 * scale }]}>Completed Tasks</Text>
            </View>

            {/* Divider */}
            <View style={[styles.divider, { height: 60 * scale }]} />

            {/* Right Stat */}
            <View style={styles.statItem}>
              <Text style={[styles.statNumber, { fontSize: 32 * scale }]}>9701</Text>
              <Text style={[styles.statUnit, { fontSize: 14 * scale }]}>words</Text>
              <Text style={[styles.statLabel, { fontSize: 12 * scale }]}>Total diary word count</Text>
            </View>
          </View>

          {/* Horizontal Line */}
          <View style={[styles.horizontalLine, { marginTop: 15 * scale }]} />

          {/* Diary Entries Grid */}
          <View style={[styles.diaryGrid, {
            paddingTop: 20 * scale,
            paddingBottom: 40 * scale,
          }]}>
          {/* First Row */}
          <View style={styles.diaryRow}>
            <View style={[styles.diaryCard, {
              width: (width - 60 * scale) / 2,
              height: 200 * scale,
              marginRight: 10 * scale,
              marginBottom: 10 * scale,
            }]}>
              <View style={[styles.diaryImagePlaceholder, {
                width: '100%',
                height: 140 * scale,
              }]}>
                <SvgXml xml={photoSvg} width="100%" height="100%" />
              </View>
              <Text style={[styles.diaryTitle, { fontSize: 12 * scale, marginTop: 8 * scale }]}>Diary Title</Text>
            </View>

            <View style={[styles.diaryCard, {
              width: (width - 60 * scale) / 2,
              height: 200 * scale,
              marginLeft: 10 * scale,
              marginBottom: 10 * scale,
            }]}>
              <View style={[styles.diaryImagePlaceholder, {
                width: '100%',
                height: 140 * scale,
              }]}>
                <SvgXml xml={photoSvg} width="100%" height="100%" />
              </View>
              <Text style={[styles.diaryTitle, { fontSize: 12 * scale, marginTop: 8 * scale }]}>Diary Title</Text>
            </View>
          </View>

          {/* Second Row */}
          <View style={styles.diaryRow}>
            <View style={[styles.diaryCard, {
              width: (width - 60 * scale) / 2,
              height: 200 * scale,
              marginRight: 10 * scale,
            }]}>
              <View style={[styles.diaryImagePlaceholder, {
                width: '100%',
                height: 140 * scale,
              }]}>
                <SvgXml xml={photoSvg} width="100%" height="100%" />
              </View>
              <Text style={[styles.diaryTitle, { fontSize: 12 * scale, marginTop: 8 * scale }]}>Diary Title</Text>
            </View>

            <View style={[styles.diaryCard, {
              width: (width - 60 * scale) / 2,
              height: 200 * scale,
              marginLeft: 10 * scale,
            }]}>
              <View style={[styles.diaryImagePlaceholder, {
                width: '100%',
                height: 140 * scale,
              }]}>
                <SvgXml xml={photoSvg} width="100%" height="100%" />
              </View>
              <Text style={[styles.diaryTitle, { fontSize: 12 * scale, marginTop: 8 * scale }]}>Diary Title</Text>
            </View>
          </View>
          </View>
        </View>
      </ScrollView>

      {/* Sidebar Overlay */}
      {sidebarVisible && (
        <TouchableOpacity
          style={styles.overlay}
          activeOpacity={1}
          onPress={closeSidebar}
        />
      )}

      {/* Sidebar - Slides in from right */}
      {sidebarVisible && (
        <Animated.View
          style={[
            styles.sidebar,
            {
              width: width * 0.75 * 0.8,
              transform: [{ translateX: sidebarTranslateX }],
            },
          ]}
        >
          <View style={styles.sidebarContainer}>
            <ScrollView style={styles.sidebarContent} showsVerticalScrollIndicator={false}>
            {/* Sidebar header */}
            <View style={[styles.sidebarHeader, { paddingTop: 60 * scale }]}>
              <TouchableOpacity onPress={closeSidebar} style={styles.arrowButton}>
                <Ionicons name="chevron-forward" size={24 * scale} color="#000000" />
              </TouchableOpacity>
            </View>

            {/* Sidebar menu items */}
            <View style={[styles.sidebarMenu, { marginTop: 0 }]}>
              {/* Settings */}
              <TouchableOpacity style={styles.menuItemContainer}>
                <View style={styles.menuItemRow}>
                  <Ionicons name="settings-outline" size={20 * scale} color="#000000" />
                  <Text style={[styles.menuItemText, { fontSize: 16 * scale }]}>Settings</Text>
                </View>
              </TouchableOpacity>
              
              <View style={styles.dividerLine} />

              {/* Dark Mode Section */}
              <View style={styles.menuItemContainer}>
                <View style={styles.menuItemRow}>
                  <Ionicons name="moon-outline" size={20 * scale} color="#000000" />
                  <Text style={[styles.menuItemText, { fontSize: 16 * scale }]}>Dark Mode</Text>
                  <Switch
                    value={darkModeEnabled}
                    onValueChange={handleDarkModeToggle}
                    trackColor={{ false: '#E0E0E0', true: '#71D1EE' }}
                    thumbColor="#FFFFFF"
                  />
                </View>
              </View>

              {/* Automatic - Indented */}
              <View style={[styles.menuItemContainer, { paddingLeft: 40 * scale }]}>
                <View style={styles.menuItemRow}>
                  <Text style={[styles.menuItemText, { fontSize: 16 * scale }]}>Automatic</Text>
                  <Switch
                    value={automaticEnabled}
                    onValueChange={handleAutomaticToggle}
                    trackColor={{ false: '#E0E0E0', true: '#71D1EE' }}
                    thumbColor="#FFFFFF"
                  />
                </View>
              </View>

              {/* Follow system - Indented */}
              <View style={[styles.menuItemContainer, { paddingLeft: 40 * scale }]}>
                <View style={styles.menuItemRow}>
                  <Text style={[styles.menuItemText, { fontSize: 16 * scale }]}>Follow system</Text>
                  <Switch
                    value={followSystemEnabled}
                    onValueChange={handleFollowSystemToggle}
                    trackColor={{ false: '#E0E0E0', true: '#71D1EE' }}
                    thumbColor="#FFFFFF"
                  />
                </View>
              </View>

              <View style={styles.dividerLine} />

              {/* Language */}
              <TouchableOpacity style={styles.menuItemContainer}>
                <View style={styles.menuItemRow}>
                  <Ionicons name="globe-outline" size={20 * scale} color="#000000" />
                  <Text style={[styles.menuItemText, { fontSize: 16 * scale }]}>Language</Text>
                </View>
              </TouchableOpacity>

              <View style={styles.dividerLine} />

              {/* About Us */}
              <TouchableOpacity style={styles.menuItemContainer}>
                <View style={styles.menuItemRow}>
                  <Ionicons name="information-circle-outline" size={20 * scale} color="#000000" />
                  <Text style={[styles.menuItemText, { fontSize: 16 * scale }]}>About Us</Text>
                </View>
              </TouchableOpacity>
            </View>
            </ScrollView>

            {/* Log Out - Fixed at bottom */}
            <View style={styles.logoutContainer}>
              <View style={styles.dividerLine} />
              <TouchableOpacity style={styles.menuItemContainer} onPress={handleLogout}>
                <View style={styles.menuItemRow}>
                  <Ionicons name="log-out-outline" size={20 * scale} color="#000000" />
                  <Text style={[styles.menuItemText, { fontSize: 16 * scale }]}>Log Out</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </Animated.View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFB',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  profileSection: {
    alignItems: 'center',
    paddingBottom: 20,
  },
  avatarCircle: {
    backgroundColor: '#FFD9AA',
  },
  userName: {
    fontFamily: 'System',
    fontWeight: '700',
    color: '#000000',
    textAlign: 'center',
  },
  signature: {
    fontFamily: 'System',
    fontWeight: '400',
    color: '#666666',
    textAlign: 'center',
  },
  yellowSection: {
    backgroundColor: '#FFF7DA',
    width: width,
    minHeight: height,
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statNumber: {
    fontFamily: 'System',
    fontWeight: '700',
    color: '#000000',
  },
  statUnit: {
    fontFamily: 'System',
    fontWeight: '400',
    color: '#666666',
    marginTop: 4,
  },
  statLabel: {
    fontFamily: 'System',
    fontWeight: '400',
    color: '#666666',
    marginTop: 4,
    textAlign: 'center',
  },
  divider: {
    width: 1,
    backgroundColor: '#E0E0E0',
    marginHorizontal: 20,
  },
  horizontalLine: {
    width: '100%',
    height: 1,
    backgroundColor: '#E0E0E0',
  },
  diaryGrid: {
    alignItems: 'center',
    width: '100%',
  },
  diaryRow: {
    flexDirection: 'row',
    marginBottom: 10,
    justifyContent: 'center',
    width: width - 60,
    alignSelf: 'center',
  },
  diaryCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    overflow: 'hidden',
    padding: 8,
  },
  diaryImagePlaceholder: {
    borderRadius: 8,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  diaryTitle: {
    fontFamily: 'System',
    fontWeight: '400',
    color: '#000000',
    textAlign: 'center',
  },
  menuIconButton: {
    position: 'absolute',
    zIndex: 100,
    padding: 8,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 200,
  },
  sidebar: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#FFFFFF',
    zIndex: 300,
    shadowColor: '#000',
    shadowOffset: { width: -2, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 3,
    elevation: 5,
    borderTopLeftRadius: 12,
    borderBottomLeftRadius: 12,
  },
  sidebarContainer: {
    flex: 1,
    flexDirection: 'column',
  },
  sidebarContent: {
    flex: 1,
  },
  logoutContainer: {
    paddingBottom: 20,
  },
  sidebarHeader: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  arrowButton: {
    padding: 8,
  },
  sidebarMenu: {
    flex: 1,
    paddingTop: 0,
  },
  menuItemContainer: {
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  menuItemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  menuItemText: {
    fontFamily: 'System',
    fontWeight: '400',
    color: '#000000',
    marginLeft: 12,
    flex: 1,
  },
  dividerLine: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginHorizontal: 20,
  },
});
